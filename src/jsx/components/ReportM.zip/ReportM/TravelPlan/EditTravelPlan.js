import React, { Fragment, useEffect, useRef, useState } from "react";
// import styles
import 'lightgallery/css/lightgallery.css';
import 'lightgallery/css/lg-zoom.css';
import 'lightgallery/css/lg-thumbnail.css';
import AdminPageTitle from "../../AdminPageTitle/AdminPageTitle";
import axios from "axios";
import { API_URL } from "../../../../config.js";
import { useNavigate, useParams } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
let styles={"cursor":'not-allowed',"background":"#DDDDDD"}
const EditTravelPlan = () => {
    const navigate = useNavigate();
    const { id } = useParams();
    const [formData, setFormData] = useState({
        payment_plan: '',
        plan_type: '',
        conditions: '',
        local_govt: '',
        direct_debit:'',
        budget: '',
        state: '',
    });
    useEffect(async () => {
        const { data } = await axios.get(`${API_URL}/api/travel_plan_master/${id}`)
        const {plan_type,payment_plan,conditions,direct_debit,local_govt,budget,state} = data
        setFormData({
            ...formData,
            payment_plan: payment_plan,
            plan_type: plan_type,
            conditions: conditions,
            local_govt: local_govt,
            budget: budget,
            direct_debit: direct_debit,
            state: state

        })
        // setState(data)
        console.log(data);

    }, [])


    const handleRedirect = async (e) => {
        navigate('/admin/view/view_travel_plan')
    };

console.log("log",formData);
 return (
        <Fragment>
            <AdminPageTitle activePage="Hospital Management" pageName="Add Hospital" />

            <div className="col-xl-12 row-lg-12" >
                <div className="card" >
                    <div className="card-header">
                        <h4 className="card-title">View Corporate Plan</h4>
                    </div>

                    <div className="card-body">
                        <div className="basic-form">

                            <form onSubmit={handleRedirect}>
                                <div className="row">


                                    <div className="form-group mb-3 col-md-6">
                                        <label className="col-sm-3 col-form-label">State</label>
                                        <div className="col-sm-9">
                                            <input
                                                name="state"
                                                type="text"
                                                disabled
                                                className="form-control"
                                                placeholder="state"
                                                value={formData.state}
                                                style={styles}
                                            />
                                        </div>
                                    </div>
                                    <div className="form-group mb-3 col-md-6">
                                        <label className="col-sm-3 col-form-label">Local Goverment</label>
                                        <div className="col-sm-9">

                                            <input
                                                name="local_govt"
                                                type="text"
                                                disabled
                                                className="form-control"
                                                style={styles}                                                value={formData.local_govt}
                                            // onChange={handleChange}

                                            />
                                        </div>
                                    </div>

                                </div>

                                <div className="row">
                                    <div className="form-group mb-3 col-md-6">
                                        <label className="col-sm-3 col-form-label">Plan Type</label>
                                        <div className="col-sm-9">
                                            <input
                                                name="plan_type"
                                                type="text"
                                                disabled
                                                className="form-control"
                                                style={styles}                                                value={formData.plan_type}
                                            // onChange={handleChange}

                                            />
                                        </div>
                                    </div>
                                    <div className="form-group mb-3 col-md-6">
                                        <label className="col-sm-3 col-form-label">Payment Plan</label>
                                        <div className="col-sm-9">
                                            <input
                                                name="payment_plan"
                                                type="text"
                                                className="form-control"
                                                placeholder="Payment Plan"
                                                value={formData.payment_plan}
                                                disabled
                                                style={styles}
                                            />
                                        </div>
                                    </div>

                                </div>

                                <div className="row">

                                    <div className="form-group mb-3 col-md-6">
                                        <label className="col-sm-3 col-form-label">Conditions</label>
                                        <div className="col-sm-9">

                                            <input
                                                type="text"
                                                name="conditions"
                                                className="form-control"
                                                placeholder="conditions"
                                                value={formData.conditions}
                                                style={styles}                                                
                                                disabled
                                            // onBlur={handleBlur}

                                            />
                                        </div>
                                    </div>
                                    <div className="form-group mb-3 col-md-6">
                                        <label className="col-sm-3 col-form-label">Budget</label>
                                        <div className="col-sm-9">
                                            <input
                                                name="budget"
                                                type="text"
                                                disabled
                                                className="form-control"
                                                // placeholder="enter hospital name"
                                                value={formData.budget}
                                                style={styles}
                                            />
                                        </div>
                                    </div>

                                </div>

                                <div className="row">
                                    <div className="form-group mb-3 col-md-6">
                                        <label className="col-sm-3 col-form-label">Direct Debit</label>
                                        <div className="col-sm-9">
                                            <input
                                                type="text"
                                                name="direct_debit"
                                                className="form-control"
                                                value={formData.direct_debit}
                                                disabled
                                                style={styles}
                                            />
                                        </div>
                                    </div>

                                </div>
                                <div className="col-sm-10">
                                    <button type="submit" className="btn btn-primary">
                                        Close
                                    </button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>

            </div>
            <ToastContainer />
        </Fragment>
    );
};

export default EditTravelPlan;

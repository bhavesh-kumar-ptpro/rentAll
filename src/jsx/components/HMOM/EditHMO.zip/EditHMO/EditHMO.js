// import React, { Fragment, useEffect, useReducer, useState } from "react";
// import { Link, useNavigate } from "react-router-dom";
// // import styles
// import 'lightgallery/css/lightgallery.css';
// import 'lightgallery/css/lg-zoom.css';
// import 'lightgallery/css/lg-thumbnail.css';
// //** Import Image */
// //** Import Image */
// import PageTitle from "../../../layouts/PageTitle";
// import axios from "axios";
// import { useParams } from 'react-router-dom';
// const EditHMO = () => {
//     const { param } = useParams();
// 	const [userData, setUserData] = useState({})
//   const [formData, setFormData] = useState({
//     company_name: '',
//     email: '',
//     contact_no: '',
//     contact_person: '',
//     address: '',
//     logo_url: ""
//   });
//   useEffect(()=>{
//     handleGetEdit()
//   },[])
//   const handleSubmit = async (e) => {
// 		// setUserData({[e.target.name]: e.target.value })
// 		console.log("handleSubmit", formData);
// 		try {
// 			const response = await axios.post(`http://localhost:3000/api/hmo`, formData);
// 			console.log('Response data:', response.data);
// 			return response.data;
// 		} catch (error) {
// 			if (error.response) {
// 				console.error('Error response:', error.response.data);
// 			} else if (error.request) {
// 				console.error('Error request:', error.request);
// 			} else {
// 				console.error('Error message:', error.message);
// 			}
// 			throw error;
// 		}
// 	}
// 	const handleGetEdit = async () => {
// 		try {
// 			const response = await axios.get(`http://localhost:3000/api/hmo/${param}`);
// 			console.log('Response get:', response.data);
//       setFormData({...formData,company_name:response.data.company_name,
//       email: response.data.email,
//       contact_no: response.data.contact_no,
//       contact_person: response.data.contact_person,
//       address: response.data.address,
//       logo_url: response.data.logo_url})

//       console.log("param",formData);

// 			return response.data;
// 		} catch (error) {
// 				console.error('Error message:', error.message);
// 			throw error;
// 		}
// 	}
//   const navigate = useNavigate()

// const handleChange = (e) => {
//   const { name, value } = e.target;

//   setFormData({
//     ...formData,
//     [name]: value
//   });
//   console.log("handleSubmit", formData);
// };
// 	return (
// 		<Fragment>
// 			<PageTitle activeMenu="Add-HMO" motherMenu="App" />
// 			<div className="col-xl-6 col-lg-12">
// 				<div className="card" style={{ display: "flex" }}>
// 					<div className="card-header">
// 						<h4 className="card-title">Edit HMO</h4>
// 					</div>
// 					<div className="card-body" >
// 						<div className="basic-form" >
// 							<form onSubmit={(e) => handleSubmit(e)}>
// 								<div className="mb-3 row">
// 									<label className="col-sm-3 col-form-label">HMO Name</label>
// 									<div className="col-sm-9">
// 										<input
// 											name="company_name"
// 											type="text"
// 											className="form-control"
// 											placeholder="Name"
// 											value={formData.company_name}
// 											onChange={handleChange}
// 											required
// 										/>
// 									</div>
// 								</div>
// 								<div className="mb-3 row">
// 									<label className="col-sm-3 col-form-label">Email</label>
// 									<div className="col-sm-9">
// 										<input
// 											name="email"
// 											type="email"
// 											className="form-control"
// 											placeholder="Email"
// 											value={formData.email}
// 											onChange={handleChange}
// 											required
// 										/>
// 									</div>
// 								</div>
// 								<div className="mb-3 row">
// 									<label className="col-sm-3 col-form-label">Contact No</label>
// 									<div className="col-sm-9">
// 										<input
// 											name="contact_no"
// 											type="text"
// 											maxLength={10}
// 											className="form-control"
// 											placeholder="Contact No"
// 											value={formData.contact_no}
// 											onChange={handleChange}
// 											required
// 										/>
// 									</div>
// 								</div>
// 								<div className="mb-3 row">
// 									<label className="col-sm-3 col-form-label">Contact Person</label>
// 									<div className="col-sm-9">
// 										<input
// 											name="contact_person"
// 											type="text"
// 											className="form-control"
// 											placeholder="Contact Person"
// 											value={formData.contact_person}
// 											onChange={handleChange}
// 											required
// 										/>
// 									</div>
// 								</div>
// 								<div className="mb-3 row">
// 									<label className="col-sm-3 col-form-label">Address</label>
// 									<div className="col-sm-9">
// 										<input
// 											type="text"
// 											name="address"
// 											className="form-control"
// 											placeholder="Address"
// 											value={formData.address}
// 											onChange={handleChange}
// 											required
// 										/>
// 									</div>
// 									<div className="mb-3" style={{marginTop:"15px",marginBottom:"15px"}}>
// 										<label htmlFor="formFile" className="form-label">Upload logo image</label>
// 										<input className="form-control" type="file" id="formFile" name="logo_url" value={formData.logo_url} onChange={handleChange} />
// 									</div>
// 								</div>

// 								<div className="mb-3 row">
// 									<div className="col-sm-10">
// 										<button type="submit" className="btn btn-primary">
// 											Submit
// 										</button>
// 									</div>
// 								</div>
// 							</form>

// 						</div>
// 					</div>
// 				</div>
// 			</div>
// 		</Fragment>
// 	);
// };

// export default EditHMO;
// import React, { Fragment, useEffect, useReducer, useState } from "react";
// import { Link, useNavigate, useParams } from "react-router-dom";
// import axios from "axios";
// import PageTitle from "../../../layouts/PageTitle";

// const initialState = {
//   sendMessage: false,
//   post: false,
//   link: false,
//   camera: false,
//   reply: false,
// };

// const reducer = (state, action) => {
//   switch (action.type) {
//     case "sendMessage":
//       return { ...state, sendMessage: !state.sendMessage };
//     case "postModal":
//       return { ...state, post: !state.post };
//     case "linkModal":
//       return { ...state, link: !state.link };
//     case "cameraModal":
//       return { ...state, camera: !state.camera };
//     case "replyModal":
//       return { ...state, reply: !state.reply };
//     default:
//       return state;
//   }
// };

// const EditHMO = () => {
//   const { param } = useParams();
//   const navigate = useNavigate();

//   const [formData, setFormData] = useState({
//     company_name: "",
//     email: "",
//     contact_no: "",
//     contact_person: "",
//     address: "",
//     logo_url: "",
//   });

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData({
//       ...formData,
//       [name]: value,
//     });
//   };

//   const handleFileChange = (e) => {
//     setFormData({
//       ...formData,
//       logo_url: e.target.files[0],
//     });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const data = new FormData();
//     for (const key in formData) {
//       data.append(key, formData[key]);
//     }
//     try {
//       const response = await axios.post(`http://localhost:3000/api/hmo`, data, {
//         headers: {
//           "Content-Type": "multipart/form-data",
//         },
//       });
//       console.log("Response data:", response.data);
//       setFormData({
//         company_name: "",
//         email: "",
//         contact_no: "",
//         contact_person: "",
//         address: "",
//         logo_url: "",
//       });
//       navigate("/view-hmo"); // Adjust the path to where you want to redirect
//     } catch (error) {
//       if (error.response) {
//         console.error("Error response:", error.response.data);
//       } else if (error.request) {
//         console.error("Error request:", error.request);
//       } else {
//         console.error("Error message:", error.message);
//       }
//     }
//   };

//   const handleGetEdit = async () => {
//     try {
//       const response = await axios.get(`http://localhost:3000/api/hmo/${param}`);
//       const { company_name, email, contact_no, contact_person, address, logo_url } = response.data;
//       setFormData({ company_name, email, contact_no, contact_person, address, logo_url });
//     } catch (error) {
//       console.error("Error message:", error.message);
//     }
//   };

//   useEffect(() => {
//     handleGetEdit();
//   }, [param]);

//   const [state, dispatch] = useReducer(reducer, initialState);

//   return (
//     <Fragment>
//       <PageTitle activeMenu="Add-HMO" motherMenu="App" />
//       <div className="col-xl-6 col-lg-12">
//         <div className="card" style={{ display: "flex" }}>
//           <div className="card-header">
//             <h4 className="card-title">Edit HMO</h4>
//           </div>
//           <div className="card-body">
//             <div className="basic-form">
//               <form onSubmit={handleSubmit}>
//                 <div className="mb-3 row">
//                   <label className="col-sm-3 col-form-label">HMO Name</label>
//                   <div className="col-sm-9">
//                     <input
//                       name="company_name"
//                       type="text"
//                       className="form-control"
//                       placeholder="Name"
//                       value={formData.company_name}
//                       onChange={handleChange}
//                       required
//                     />
//                   </div>
//                 </div>
//                 <div className="mb-3 row">
//                   <label className="col-sm-3 col-form-label">Email</label>
//                   <div className="col-sm-9">
//                     <input
//                       name="email"
//                       type="email"
//                       className="form-control"
//                       placeholder="Email"
//                       value={formData.email}
//                       onChange={handleChange}
//                       required
//                     />
//                   </div>
//                 </div>
//                 <div className="mb-3 row">
//                   <label className="col-sm-3 col-form-label">Contact No</label>
//                   <div className="col-sm-9">
//                     <input
//                       name="contact_no"
//                       type="text"
//                       maxLength={10}
//                       className="form-control"
//                       placeholder="Contact No"
//                       value={formData.contact_no}
//                       onChange={handleChange}
//                       required
//                     />
//                   </div>
//                 </div>
//                 <div className="mb-3 row">
//                   <label className="col-sm-3 col-form-label">Contact Person</label>
//                   <div className="col-sm-9">
//                     <input
//                       name="contact_person"
//                       type="text"
//                       className="form-control"
//                       placeholder="Contact Person"
//                       value={formData.contact_person}
//                       onChange={handleChange}
//                       required
//                     />
//                   </div>
//                 </div>
//                 <div className="mb-3 row">
//                   <label className="col-sm-3 col-form-label">Address</label>
//                   <div className="col-sm-9">
//                     <input
//                       type="text"
//                       name="address"
//                       className="form-control"
//                       placeholder="Address"
//                       value={formData.address}
//                       onChange={handleChange}
//                       required
//                     />
//                   </div>
//                 </div>
//                 <div className="mb-3" style={{ marginTop: "15px", marginBottom: "15px" }}>
//                   <label htmlFor="formFile" className="form-label">Upload logo image</label>
//                   <input
//                     className="form-control"
//                     type="file"
//                     id="formFile"
//                     name="logo_url"
//                     onChange={handleFileChange}
//                   />
//                 </div>
//                 <div className="mb-3 row">
//                   <div className="col-sm-10">
//                     <button type="submit" className="btn btn-primary">
//                       Submit
//                     </button>
//                   </div>
//                 </div>
//               </form>
//             </div>
//           </div>
//         </div>
//       </div>
//     </Fragment>
//   );
// };

// export default EditHMO;
import React, { Fragment, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import 'lightgallery/css/lightgallery.css';
import 'lightgallery/css/lg-zoom.css';
import 'lightgallery/css/lg-thumbnail.css';
import PageTitle from "../../../layouts/PageTitle";
import AdminPageTitle from "../../AdminPageTitle/AdminPageTitle";
import axios from "axios";
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { CKEditor } from '@ckeditor/ckeditor5-react';
const EditHMO = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    company_name: '',
    email: '',
    contact_no: '',
    contact_person: '',
    address: '',
    logo_url: ""
  });
  const [fileName, setFileName] = useState("");

  useEffect(() => {
    handleGetEdit();
  }, [id]);
console.log(id,"edit");
  const handleGetEdit = async () => {
    try {
      const response = await axios.get(`http://localhost:3000/api/hmo/${id}`);
      const { company_name, email, contact_no, contact_person, address, logo_url } = response.data;
      setFormData({ company_name, email, contact_no, contact_person, address, logo_url });
      setFileName(logo_url); // Assuming logo_url is a URL or file name
    } catch (error) {
      console.error('Error fetching HMO data:', error.message);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = new FormData();
    for (const key in formData) {
      data.append(key, formData[key]);
    }

    try {
      const response = await axios.put(`http://localhost:3000/api/hmo/${id}`, formData);
      console.log('Response data:', response.data);
      setFormData({
        company_name: '',
        email: '',
        contact_no: '',
        contact_person: '',
        address: '',
        logo_url: ""
      });
      setFileName("");
      navigate("/admin/view/ViewHMO"); // Adjust the path to where you want to redirect
    } catch (error) {
      console.error('Error submitting HMO data:', error.message);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setFormData({
      ...formData,
      logo_url: file
    });

    if (file) {
      setFileName(file.name);
    } else {
      setFileName("");
    }
  };

  return (
    <Fragment>
      <AdminPageTitle activePage="HMO Management"  pageName="EditHMO" />
      <div className="col-xl-8 col-lg-12">
        <div className="card" style={{ display: "flex" }}>
          <div className="card-header">
            <h4 className="card-title">Update-HMO</h4>
          </div>
          <div className="card-body">
            <div className="basic-form">
              <form onSubmit={handleSubmit}>
                <div className="mb-3 row">
                  <label className="col-sm-3 col-form-label">HMO Name</label>
                  <div className="col-sm-9">
                    <input
                      name="company_name"
                      type="text"
                      className="form-control"
                      placeholder="Name"
                      value={formData.company_name}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
                <div className="mb-3 row">
                  <label className="col-sm-3 col-form-label">Email</label>
                  <div className="col-sm-9">
                    <input
                      name="email"
                      type="email"
                      className="form-control"
                      placeholder="Email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
                <div className="mb-3 row">
                  <label className="col-sm-3 col-form-label">Contact No</label>
                  <div className="col-sm-9">
                    <input
                      name="contact_no"
                      type="text"
                      maxLength={10}
                      className="form-control"
                      placeholder="Contact No"
                      value={formData.contact_no}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
                <div className="mb-3 row">
                  <label className="col-sm-3 col-form-label">Contact Person</label>
                  <div className="col-sm-9">
                    <input
                      name="contact_person"
                      type="text"
                      className="form-control"
                      placeholder="Contact Person"
                      value={formData.contact_person}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
                <div className="mb-3 row">
                  <label className="col-sm-3 col-form-label">Address</label>
                  <div className="col-sm-9">
                    <input
                      type="text"
                      name="address"
                      className="form-control"
                      placeholder="Address"
                      value={formData.address}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
                <div className="mb-3 row">
                  <label htmlFor="formFile" className="col-sm-3 col-form-label">Update logo image</label>
                  <div className="col-sm-9">
                    <input
                      className="form-control"
                      type="file"
                      id="formFile"
                      name="logo_url"
                      onChange={handleFileChange}
                    />
                    {fileName && <p className="mt-2">{fileName}</p>}
                  </div>
                </div>
                <div className="mb-3 row">
                  <label htmlFor="formFile" className="col-sm-3 col-form-label">Update video</label>
                  <div className="col-sm-9">
                    <input
                      className="form-control"
                      type="file"
                      id="formFile"
                      name="video_url"
                      onChange={handleFileChange}
                    />
                    {fileName && <p className="mt-2">{fileName}</p>}
                  </div>
                </div>
                
                <div className="col-xl-12 col-xxl-12">
                        <div className="card">
                            <div className="card-header">
                                <h4 className="card-title">Description 1</h4>
                            </div>
                            <div className="card-body custom-ekeditor">
                                {/* <h2>Using CKEditor 5 build in React</h2> */}
                                <CKEditor
                                    editor={ ClassicEditor }
                                // data="<p>Hello from CKEditor 5!</p>"
                                    onReady={ editor => {
                                        // You can store the "editor" and use when it is needed.
                                        console.log( 'Editor is ready to use!', editor );
                                    } }
                                    onChange={ ( event, editor ) => {
                                        const data = editor.getData();
                                        console.log( { event, editor, data } );
                                    } }
                                    onBlur={ ( event, editor ) => {
                                        console.log( 'Blur.', editor );
                                    } }
                                    onFocus={ ( event, editor ) => {
                                        console.log( 'Focus.', editor );
                                    } }
                                />
                            </div>
                        </div>
                    </div>        
                    <div className="col-xl-12 col-xxl-12">
                        <div className="card">
                            <div className="card-header">
                                <h4 className="card-title">Description 2</h4>
                            </div>
                            <div className="card-body custom-ekeditor">
                                {/* <h2>Using CKEditor 5 build in React</h2> */}
                                <CKEditor
                                    editor={ ClassicEditor }
                                // data="<p>Hello from CKEditor 5!</p>"
                                    onReady={ editor => {
                                        // You can store the "editor" and use when it is needed.
                                        console.log( 'Editor is ready to use!', editor );
                                    } }
                                    onChange={ ( event, editor ) => {
                                        const data = editor.getData();
                                        console.log( { event, editor, data } );
                                    } }
                                    onBlur={ ( event, editor ) => {
                                        console.log( 'Blur.', editor );
                                    } }
                                    onFocus={ ( event, editor ) => {
                                        console.log( 'Focus.', editor );
                                    } }
                                />
                            </div>
                        </div>
                    </div>  
                <div className="mb-3 row">
                  <div className="col-sm-10">
                    <button type="submit" className="btn btn-primary">Update</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </Fragment>
  );
};

export default EditHMO;

import React, { Fragment, useEffect, useReducer, useState,useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import LightGallery from 'lightgallery/react';
// import styles
// import 'lightgallery/css/lightgallery.css';
// import 'lightgallery/css/lg-zoom.css';
// import 'lightgallery/css/lg-thumbnail.css';
import './filtering.css'
import {
    Row,
    Col,
    Card,
    Table,
    Badge,
    Dropdown,
    ProgressBar,
  } from "react-bootstrap";
//** Import Image */
//** Import Image */
import AdminPageTitle from "../../AdminPageTitle/AdminPageTitle";
import axios from "axios";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import swal from 'sweetalert';
import { API_URL }from "../../../../apiconfig";


const ViewHMO = () => {
  const sort = 10;
  const activePag = useRef(0);
	const [userData, setUserData] = useState([])
  useEffect(()=>{
    handleSubmit()
  },[])
  let paggination = [];
  let jobData = [];
  // if(userData && userData.length > 0) {
    // console.log(userData.length,"user");
     paggination = Array(Math.ceil(userData.length / sort))
    .fill()
    .map((_, i) => i + 1);
    jobData =userData.slice(
      activePag.current * sort,
      (activePag.current + 1) * sort
    )
  // }
  //  jobData = useRef(
    
  // );
  
	const handleSubmit = async () => {

		try {
			const response = await axios.get(`${API_URL}/api/hmo`);
			console.log('Response data:', response.data);
      setUserData(response.data)
			return response.data;
		} catch (error) {
				console.error('Error message:', error.message);
			throw error;
		}
	}
  const navigate = useNavigate()
const handleDelete = async (id)=>{
  swal({
    title: "Are you sure?",
    text:
      "Once deleted, you will not be able to recover this record!",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  }).then(async (willDelete) => {
    if (willDelete) {
      try {
    const response = await axios.put(`${API_URL}/api/hmo/delete/${id}`);
    console.log('Response data:', response.data);
    handleSubmit()
    return response.data;
  } catch (error) {
      console.error('Error message:', error.message);
    throw error;
  }
    }
  })
  console.log(id,"delete");
	
}

const onClick = (i) => {
  activePag.current = i;

  jobData = userData.slice(
    activePag.current * sort,
    (activePag.current + 1) * sort
  );
  /* setdemo(
    data.profileTable.data.slice(
      activePag.current * sort,
      (activePag.current + 1) * sort
    )
  ); */
};



	return (
		<Fragment>
			<AdminPageTitle activePage="HMO Management"  pageName="ViewHMO" />
		
            <Col lg={12}>
          <Card>
            <Card.Header>
              <Card.Title>HMO Details</Card.Title>
            </Card.Header>
            <Card.Body>
            {/* <select
                          defaultValue={"option"}
                          className="form-control form-control-lg"
                          id="inlineFormCustomSelect"
                        >
                          <option value="option" disabled>
                            Choose...
                          </option>
                          <option value="1">One</option>
                          <option value="2">Two</option>
                          <option value="3">Three</option>
                        </select> */}
              <Table responsive>
                <thead>
                  <tr>
                    <th>
                      <strong>HMO Name</strong>
                    </th>
                    <th>
                      <strong>Logo</strong>
                    </th>
                    <th>
                      <strong>Action</strong>
                    </th>
                  </tr>
                </thead>
                
                <tbody>
                
                  {/* <tr>
                    <td>Bhavesh</td>
                    <td>
                      <div className="d-flex align-items-center">
                        <img
                          src={avatar3}
                          width="50"
                          alt=""
                        />{" "}
  
                      </div>
                    </td>
                    <td>
                      <div className="d-flex">
                        <Link
                          href="#"
                          className="btn btn-primary shadow btn-xs sharp me-1"
                        >
                          <i className="fas fa-pen"></i>
                        </Link>
                        <Link
                          href="#"
                          className="btn btn-danger shadow btn-xs sharp"
                        >
                          <i className="fa fa-trash"></i>
                        </Link>
                      </div>
                    </td>
                
                  </tr> */}
                  {userData && userData.length>0 && jobData.map((user,i)=>{
                      return(
                        <tr key={i}>
                        <td>{user.company_name}</td>
                        <td><div className="d-flex align-items-center">
                        <img
                          src={"../../image/Company_Logo/"+user.logo_url}
                          width="50"
                          alt="http://placehold.it/232x232"
                        />{" "}
  
                      </div> </td>
                        <td>
                      <div className="d-flex">
                        <Link
                          // href={`/add-hmo/${user.id}`}
                        to={`/admin/view/EditHMO/${user.id}`}
                          className="btn btn-primary shadow btn-xs sharp me-1"
                        >
                          <i className="fas fa-pen"></i>
                        </Link>
                        <Link
                         onClick={()=>handleDelete(user.id)}
                          className="btn btn-danger shadow btn-xs sharp"
                        >
                          <i className="fa fa-trash"></i>
                        </Link>
                      </div>
                    </td>
                        </tr>
                      )
                    })}
                </tbody>
              </Table>
                    <div id="example_wrapper" className="dataTables_wrapper"><div className="d-sm-flex text-center justify-content-between align-items-center mt-3">
                <div className="dataTables_info">
                  Showing {activePag.current * sort + 1} to{" "}
                  {userData.length > (activePag.current + 1) * sort
                    ? (activePag.current + 1) * sort
                    : userData.length}{" "}
                  of {userData.length} entries
                </div>
                <div
                  className="dataTables_paginate paging_simple_numbers"
                  id="example5_paginate"
                >
                  <Link
                    className="paginate_button previous disabled"
                    to="/admin/view/ViewHMO"
                    onClick={() =>
                      activePag.current > 0 && onClick(activePag.current - 1)
                    }
                  >
                    <i className="fa fa-angle-double-left" aria-hidden="true"></i>
                  </Link>
                  <span>
                    {paggination.map((number, i) => (
                      <Link
                        key={i}
                        to="/admin/view/ViewHMO"
                        className={`paginate_button  ${
                          activePag.current === i ? "current" : ""
                        } `}
                        onClick={() => onClick(i)}
                      >
                        {number}
                      </Link>
                    ))}
                  </span>
                  <Link
                    className="paginate_button next"
                    to="/admin/view/ViewHMO"
                    onClick={() =>
                      activePag.current + 1 < paggination.length &&
                      onClick(activePag.current + 1)
                    }
                  >
                    <i className="fa fa-angle-double-right" aria-hidden="true"></i>
                  </Link>
                </div>
              </div></div>
              
              
            </Card.Body>
          </Card>
          <ToastContainer />
        </Col>
		</Fragment>
	);
};

export default ViewHMO;

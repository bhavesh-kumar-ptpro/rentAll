import React, { Fragment, useReducer, useState } from "react";
// import styles
import 'lightgallery/css/lightgallery.css';
import 'lightgallery/css/lg-zoom.css';
import 'lightgallery/css/lg-thumbnail.css';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { CKEditor } from '@ckeditor/ckeditor5-react';
//** Import Image */
//** Import Image */
import profile02 from "../../../../images/profile/2.jpg";
import profile03 from "../../../../images/profile/3.jpg";
import profile04 from "../../../../images/profile/4.jpg";

import AdminPageTitle from "../../AdminPageTitle/AdminPageTitle";
import axios from "axios";


const AddHMO = () => {
	const onInit = async (e) => {
		//console.log('lightGallery has been initialized');
	};
	const [userData, setUserData] = useState({})
	const [formData, setFormData] = useState({
		company_name: '',
		email: '',
		contact_no: '',
		contact_person: '',
		address: '',
		logo_url: ""
	});
	const handleChange = (e) => {
		const { name, value } = e.target;

		setFormData({
			...formData,
			[name]: value
		});
		console.log("handleSubmit", formData);
	};
	const handleSubmit = async (e) => {
		// setUserData({[e.target.name]: e.target.value })
		e.preventDefault()
		console.log("handleSubmit", formData);
		e.preventDefault()
		let data = {
			"company_name": "Max Life",
			"logo_url": "20171213133609.png",
			"email": 'bhavesh@gmail.com',
			"contact_no": 9898989889,
			"contact_person": 'bhavesh',
			"address": 'bhavesh'
		}
		try {
			const response = await axios.post("http://localhost:3000/api/hmo", formData);
			console.log('Response data:', response.data);
			setFormData({
				company_name: '',
				email: '',
				contact_no: '',
				contact_person: '',
				address: ''
			})
			return response.data;
		} catch (error) {
			if (error.response) {
				console.error('Error response:', error.response.data);
			} else if (error.request) {
				console.error('Error request:', error.request);
			} else {
				console.error('Error message:', error.message);
			}
			throw error;
		}
	}
	return (
		<Fragment>
			<AdminPageTitle activePage="HMO Management"  pageName="AddHMO" />
			<div className="col-xl-8 col-lg-12">
				<div className="card" style={{ display: "flex" }}>
					<div className="card-header">
						<h4 className="card-title">ADD HMO</h4>
					</div>
					<div className="card-body" >
						<div className="basic-form" >
							<form onSubmit={(e) => handleSubmit(e)}>
								<div className="mb-3 row">
									<label className="col-sm-3 col-form-label">HMO Name</label>
									<div className="col-sm-9">
										<input
											name="company_name"
											type="text"
											className="form-control"
											placeholder="Name"
											value={formData.company_name}
											onChange={handleChange}
											required
										/>
									</div>
								</div>
								<div className="mb-3 row">
									<label className="col-sm-3 col-form-label">Email</label>
									<div className="col-sm-9">
										<input
											name="email"
											type="email"
											className="form-control"
											placeholder="Email"
											value={formData.email}
											onChange={handleChange}
											required
										/>
									</div>
								</div>
								<div className="mb-3 row">
									<label className="col-sm-3 col-form-label">Contact No</label>
									<div className="col-sm-9">
										<input
											name="contact_no"
											type="text"
											maxLength={10}
											className="form-control"
											placeholder="Contact No"
											value={formData.contact_no}
											onChange={handleChange}
											required
										/>
									</div>
								</div>
								<div className="mb-3 row">
									<label className="col-sm-3 col-form-label">Contact Person</label>
									<div className="col-sm-9">
										<input
											name="contact_person"
											type="text"
											className="form-control"
											placeholder="Contact Person"
											value={formData.contact_person}
											onChange={handleChange}
											required
										/>
									</div>
								</div>
								<div className="mb-3 row">
									<label className="col-sm-3 col-form-label">Address</label>
									<div className="col-sm-9">
										<input
											type="text"
											name="address"
											className="form-control"
											placeholder="Address"
											value={formData.address}
											onChange={handleChange}
											required
										/>
									</div>
									<div className="mb-3" style={{marginTop:"15px",marginBottom:"15px"}}>
										<label htmlFor="formFile" className="form-label">Upload logo image</label>
										<input className="form-control" type="file" id="formFile" name="logo_url" value={formData.logo_url} onChange={handleChange} />
									</div>
									<div className="mb-3" style={{marginTop:"15px",marginBottom:"15px"}}>
										<label htmlFor="formFile" className="form-label">Upload Video</label>
										<input className="form-control" type="file" id="formFile" name="video_url" value={formData.logo_url} onChange={handleChange} />
									</div>
								</div>
								<div className="row">
                    <div className="col-xl-12 col-xxl-12">
                        <div className="card">
                            <div className="card-header">
                                <h4 className="card-title">Description 1</h4>
                            </div>
                            <div className="card-body custom-ekeditor">
                                {/* <h2>Using CKEditor 5 build in React</h2> */}
                                <CKEditor
                                    editor={ ClassicEditor }
                                // data="<p>Hello from CKEditor 5!</p>"
                                    onReady={ editor => {
                                        // You can store the "editor" and use when it is needed.
                                        console.log( 'Editor is ready to use!', editor );
                                    } }
                                    onChange={ ( event, editor ) => {
                                        const data = editor.getData();
                                        console.log( { event, editor, data } );
                                    } }
                                    onBlur={ ( event, editor ) => {
                                        console.log( 'Blur.', editor );
                                    } }
                                    onFocus={ ( event, editor ) => {
                                        console.log( 'Focus.', editor );
                                    } }
                                />
                            </div>
                        </div>
                    </div>        
                    <div className="col-xl-12 col-xxl-12">
                        <div className="card">
                            <div className="card-header">
                                <h4 className="card-title">Description 2</h4>
                            </div>
                            <div className="card-body custom-ekeditor">
                                {/* <h2>Using CKEditor 5 build in React</h2> */}
                                <CKEditor
                                    editor={ ClassicEditor }
                                // data="<p>Hello from CKEditor 5!</p>"
                                    onReady={ editor => {
                                        // You can store the "editor" and use when it is needed.
                                        console.log( 'Editor is ready to use!', editor );
                                    } }
                                    onChange={ ( event, editor ) => {
                                        const data = editor.getData();
                                        console.log( { event, editor, data } );
                                    } }
                                    onBlur={ ( event, editor ) => {
                                        console.log( 'Blur.', editor );
                                    } }
                                    onFocus={ ( event, editor ) => {
                                        console.log( 'Focus.', editor );
                                    } }
                                />
                            </div>
                        </div>
                    </div>        
                </div>  
								<div className="mb-3 row">
									<div className="col-sm-10">
										<button type="submit" className="btn btn-primary">
											Submit
										</button>
									</div>
								</div>
							</form>

						</div>
					</div>
				</div>
			</div>

		</Fragment>
	);
};

export default AddHMO;

import React, { Fragment, useState, useRef } from "react";
// import styles
import 'lightgallery/css/lightgallery.css';
import 'lightgallery/css/lg-zoom.css';
import 'lightgallery/css/lg-thumbnail.css';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { CKEditor } from '@ckeditor/ckeditor5-react';
import AdminPageTitle from "../../AdminPageTitle/AdminPageTitle";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import default_logo from "../../../../images/default logo.png"
const UploadMapping = () => {
    const navigate = useNavigate();
    const [videoFile, setVideoFile] = useState("");
    const [image, setImage] = useState({
        placeholder: "", file: null
    });
    const [fileName, setFileName] = useState("");
    const [imageFile, setImageFiles] = useState({});
    const [phoneNumber, setPhoneNumber] = useState('');
    const [error, setError] = useState('');
    const [formData, setFormData] = useState({
        excelFile: {},
    });


    // 	const file = e.target.files[0];
    // 	setImageFiles(file)
    // 	file.fieldname = "logo_url"
    // 	file.originalname = file.name
    // 	file.mimetype = file.type
    // 	console.log("file", file.type);

    // 	console.log("file", e.target.value);
    // 	if (e.target.files[0].type == "image/png" || e.target.files[0].type == "image/jpeg") {

    // 		const reader = new FileReader()
    // 		reader.onload = (r) => {
    // 			setImage({
    // 				placeholder: r.target.result,
    // 				file: e.target.files[0]
    // 			})
    // 		}
    // 		reader.readAsDataURL(file)
    // 	} else {
    // 		setFormData({
    // 			...formData,
    // 			logo_url: file
    // 		});
    // 		toast.warn("❗ Invalid Image formate", {
    // 			position: "top-right",
    // 			autoClose: 5000,
    // 			hideProgressBar: false,
    // 			closeOnClick: true,
    // 			pauseOnHover: true,
    // 			draggable: true,
    // 			progress: undefined,
    // 		});

    // 	}
    // 	console.log(file.name);
    // 	setFormData({
    // 		...formData,
    // 		logo_url: file
    // 	});
    // 	if (file) {
    // 		setFileName(file.name);
    // 	} else {
    // 		setFileName("");
    // 	}
    // };
    const handleFileChange = (e) => {
        const file = e.target.files[0];
        setFormData({ ...formData, excelFile: file })
        console.log("file", file);
    };

    const amptyField = () => {
        toast.warn("❗ Field is Empty", {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
    }
    const handleChange = (e) => {
        const { name, value } = e.target;

        setFormData({
            ...formData,
            [name]: value
        });
        console.log("value", typeof value);
    };
    const handleSubmit = async (e) => {
        e.preventDefault();
console.log("submit data",formData);
        if (formData.excelFile == "") {
            amptyField()
       
        }
        else {
            try {
                // const response = await axios.post("https://naijainsurancebackend.paperbirdtech.com/api/hmo", formData);
                // console.log('Response data:', response);
                // if (response.status == 200) {
                //     toast.success("✔️ Submision successful !", {
                //         position: "top-right",
                //         autoClose: 5000,
                //         hideProgressBar: false,
                //         closeOnClick: true,
                //         pauseOnHover: true,
                //         draggable: true,
                //         progress: undefined,
                //     });
                // }
                // navigate("/admin/view/ViewHMO");
            } catch (error) {
                // console.error('Error submitting HMO data:', error.message);
            }
        }

    };
    const handleReset = () => {
        setFormData({ ...formData, excelFile: {} })
    }
    console.log("formData", formData
    );

    return (
        <Fragment>
            <AdminPageTitle activePage="HMO Hospital Mapping" pageName="UploadMapping" />

            <div className="d-flex col-xl-10 row-lg-12" >
                <div className="card" >
                    <div className="card-header">
                        <h4 className="card-title">Upload HMO Hospital Mapping</h4>
                    </div>

                    <div className="card-body">
                        <div className="basic-form">

                            <form onSubmit={handleSubmit}>

                                <div className="mb-3 row">
                                    <label htmlFor="excelFile" className="col-sm-3 col-form-label">Upload Excel</label>
                                    <div className="col-sm-9">
                                        <input
                                            type="file"
                                            name="excelFile"
                                            className="form-control"
                                            accept=".xlsx, .xls"
                                            onChange={handleFileChange}
                                        />

                                        {/* 									
										  <input
											  type="file"
											  id="logo_url"
											  name="logo_url"
											  className="form-control"
											  onChange={handleFileChange}
											  ref={fileInputRef}
										  />
										  {imageError && <div style={{ color: 'red', marginTop: "5px" }}>{imageError}</div>} */}
                                    </div>
                                </div>
                                <div style={{ display: "flex", gap: "20px" }}>
                                    <div className="row-sm-10">
                                        <button type="submit" className="btn btn-primary">
                                            Save
                                        </button>
                                    </div>
                                    <div className="row-sm-10">
                                        <button className="btn btn-primary" onClick={handleReset}>
                                            Reset
                                        </button>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>


            </div>
            <ToastContainer />
        </Fragment>
    );
};

export default UploadMapping;

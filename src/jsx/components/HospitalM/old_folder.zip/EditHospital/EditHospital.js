// import React, { Fragment, useEffect, useState } from "react";
// import { useNavigate, useParams } from "react-router-dom";
// // import styles
// import 'lightgallery/css/lightgallery.css';
// import 'lightgallery/css/lg-zoom.css';
// import 'lightgallery/css/lg-thumbnail.css';
// import AdminPageTitle from "../../AdminPageTitle/AdminPageTitle";
// import axios from "axios";
// import { ToastContainer, toast } from "react-toastify";
// import "react-toastify/dist/ReactToastify.css";
// import { API_URL }from "../../../../apiconfig";
// const EditHospital = () => {
//     const navigate = useNavigate();
//     const { id } = useParams();
//     const [formData, setFormData] = useState({
//         hospital_name: '',
//         email: '',
//         phone: '',
//         local_govt: '',
//         address: '',
//         type_of_hospital: '',
//         city: '',
//         state: '',
//     });
//     const [selectState, setSelectState] = useState('');
//     const [state, setState] = useState([]);
// 	const [city, setCity] = useState([]);
//     const [phoneNumber, setPhoneNumber] = useState('');
// 	const [error, setError] = useState('');
//     useEffect(async () => {
//         const { data } = await axios.get(`${API_URL}/api/hospital/${id}`)
//         console.log("hospital", data);
//         const {hospital_name,city,state,type_of_hospital,phone,local_govt,address,email} = data
//         setFormData({ 
//             hospital_name:hospital_name, 
//             email:email, 
//             phone:phone, 
//             city:city, 
//             state:state, 
//             type_of_hospital:type_of_hospital, 
//             local_govt:local_govt, 
//             address:address, 
//           });
//           setPhoneNumber(phone)
//           const responce = await axios.get(`${API_URL}/api/hospital/state`)
//           setState(responce.data)
//     }, [])
//     const amptyField = () => {
//         toast.warn("❗ Field is Empty", {
//             position: "top-right",
//             autoClose: 5000,
//             hideProgressBar: false,
//             closeOnClick: true,
//             pauseOnHover: true,
//             draggable: true,
//             progress: undefined,
//         });
//     }
//     const handleChange = (e) => {
//         const { name, value } = e.target;

//         setFormData({
//             ...formData,
//             [name]: value
//         });
//         console.log("value", typeof value);
//     };
//     const getCities =async (value)=>{
//         const {data} = await axios.get(`${API_URL}/api/hospital/city/${value}`)
//         setCity(data)
//         console.log("cities",data);
//     }
//     const handleStateChange =async (e)=>{
//         const {stateValue,value} = e.target
//         if(value){
//             let selectedState = state.filter((el)=>{ return el.id == value} )
//             console.log("selectedState",selectedState[0]);
//             setSelectState(selectedState[0].state)
//             setFormData({...formData,state:selectedState[0].state,local_govt:""})
//             getCities(value)
//         }
        
//         // handleStateValue()
// // console.log("handleStateChange",value);
// // console.log("handleStateChange",e.target);

//     }
//     const handlePhoneChange = (e) => {
// 		const value = e.target.value;


// 		if (/[^0-9]/.test(value)) {
// 			setError('Please enter valid number');
// 		} else {
// 			setError('');
// 		}
// 		setPhoneNumber(value.replace(/\D/g, ''));
// 		setFormData({ ...formData, contact_no: phoneNumber })
// 	};
//     const handleBlur = () => {
//         if (phoneNumber.length !== 10) {
//             setError('Phone number must be 10 digits.');
//         }
//     };
//     const handleSubmit = async (e) => {
//         e.preventDefault();

//         const data = new FormData();
//         for (const key in formData) {
//             data.append(key, formData[key]);
//         }
//         if (formData.hospital_name == "") {
//             amptyField()
//         } else if (formData.email == "") {
//             amptyField()
//         }
//         else if ((!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,6}$/i.test(formData.email))) {
//             console.log("dfdsdsdgg");
//             toast.warn("❗ Enter valid email", {
//                 position: "top-right",
//                 autoClose: 5000,
//                 hideProgressBar: false,
//                 closeOnClick: true,
//                 pauseOnHover: true,
//                 draggable: true,
//                 progress: undefined,
//             });
//         }
//         else if (isNaN(formData.phone) || formData.phone == "" || !(formData.phone)) {
//             toast.warn("❗ Add Valid Mobile Number", {
//                 position: "top-right",
//                 autoClose: 5000,
//                 hideProgressBar: false,
//                 closeOnClick: true,
//                 pauseOnHover: true,
//                 draggable: true,
//                 progress: undefined,
//             });
//         } else if (formData.local_govt == "" || formData.address == "") {
//             amptyField()
//         }
//         else {
//             try {
//                 const response = await axios.put(`${API_URL}/api/hospital/${id}`, formData);
//                 console.log('Response data:', response);
//                 if (response.status == 200) {
//                     toast.success("✔️ Submision successful !", {
//                         position: "top-right",
//                         autoClose: 3000,
//                         hideProgressBar: false,
//                         closeOnClick: true,
//                         pauseOnHover: true,
//                         draggable: true,
//                         progress: undefined,
//                     });
//                 }
//                 navigate("/admin/view/ViewHospitals");
//             } catch (error) {
//                 console.error('Error submitting HMO data:', error.message);
//             }
//         }

//     };
//     let text = "Select local goverment";

//     return (
       
//         <Fragment>
//             <AdminPageTitle activePage="Hospital Management" pageName="Edit Hospital" />

//             <div className="col-xl-12 row-lg-12" >
//                 <div className="card" >
//                     <div className="card-header">
//                         <h4 className="card-title">Edit Hospital</h4>
//                     </div>

//                     <div className="card-body">
//                         <div className="basic-form">

//                             <form onSubmit={handleSubmit}>
//                                 <div className="row">
//                                     <div className="form-group mb-3 col-md-6">
//                                         <label className="col-sm-3 col-form-label">Hospital Name</label>
//                                         <div className="col-sm-9">
//                                             <input
//                                                 name="hospital_name"
//                                                 type="text"
//                                                 className="form-control"
//                                                 placeholder="enter hospital name"
//                                                 value={formData.hospital_name}
//                                                 onChange={handleChange}

//                                             />
//                                         </div>
//                                     </div>

//                                     <div className="form-group mb-3 col-md-6">
//                                         <label className="col-sm-3 col-form-label">Hospital type</label>
//                                         <div className="col-sm-9">
//                                             {/* <input
//                                                   type="text"
//                                                   name="type_of_hospital"
//                                                   className="form-control"
//                                                   placeholder="Hospital type"
//                                                   value={formData.type_of_hospital}
//                                                   onChange={handleChange}
//                                               /> */}

//                                             <select
//                                                 defaultValue={formData.type_of_hospital}
//                                                 className="form-control form-control"
//                                                 name="type_of_hospital"
//                                                 value={formData.type_of_hospital}
//                                                 onChange={handleChange}
//                                             >
//                                                 <option>Select hospital type</option>
//                                                 <option>Eye Hospital</option>
//                                                 <option>General Hospital</option>
//                                                 <option>Specialist Hospital</option>
//                                                 <option>Dental Hospital</option>
//                                                 <option>Meternity Hospital</option>
//                                             </select>

//                                         </div>
//                                     </div>
//                                 </div>

//                                 <div className="row">
//                                     <div className="form-group mb-3 col-md-6">
//                                         <label className="col-sm-3 col-form-label">State</label>
//                                         <div className="col-sm-9">
//                                                         <select
//                                                       defaultValue={formData.state}
//                                                       className="form-control form-control"
//                                                       name="state"
//                                                     //   value={formData.state}
//                                                       onChange={(e)=>handleStateChange(e)}
//                                                     //   onSelect={(e)=>handleStateValue(e)}
//                                                   >
//                                                       <option value={""}>{formData.state?formData.state:"Select State"}</option>

//                                                       {state && state.map((el)=>{
//                                                         return <option value={el.id} key={el.id}  >{el.state}</option>
//                                                       })}
//                                                   </select>
//                                         </div>
//                                     </div>
//                                     <div className="form-group mb-3 col-md-6">
//                                         <label className="col-sm-3 col-form-label">Contact No</label>
//                                         <div className="col-sm-9">
//                                         <input
// 											  type="text"
// 											  id="phone"
// 											  name="phone"
// 											  className="form-control"
// 											  placeholder="Contact No"
// 											  value={phoneNumber}
// 											  onChange={handlePhoneChange}
// 											  required
// 											  maxLength={10}
// 											  minLength={10}
// 											  onBlur={handleBlur}

// 										  />
// 										  {error && <div style={{ color: 'red' }}>{error}</div>}
//                                         </div>
//                                     </div>


//                                 </div>
//                                 <div className="row">


//                                     <div className="form-group mb-3 col-md-6">
//                                         <label className="col-sm-3 col-form-label">Local Goverment</label>
//                                         <div className="col-sm-9">
//                                                <select
//                                                     //   defaultValue={'Select local govt type'}
//                                                       className="form-control form-control"
//                                                       name="local_govt"
//                                                       value={formData.local_govt}
//                                                       onChange={handleChange}
                                                      
//                                                   >
//                                                     <option value={"Select"}>{formData.local_govt?formData.local_govt:text}</option>
//                                                     {city? city.map((el,i)=>{
//                                                         return(
//                                                            <option value={el.city} key={i}>{el.city}</option>
//                                                         )
//                                                     }): <option value={""}>Select local goverment</option>
//                                                 }
//                                                       {/* <option value={"Select"}>Select local govt type</option> */}
                                                     
//                                                   </select>
//                                         </div>
//                                     </div>
//                                     <div className="form-group mb-3 col-md-6">
//                                         <label className="col-sm-3 col-form-label">Email</label>
//                                         <div className="col-sm-9">
//                                             <input
//                                                 name="email"
//                                                 type="text"
//                                                 className="form-control"
//                                                 placeholder="enter valid email"
//                                                 value={formData.email}
//                                                 onChange={handleChange}

//                                             />
//                                         </div>
//                                     </div>
//                                 </div>
//                                 <div className="row">
//                                     <div className="form-group mb-3 col-md-6">
//                                         <label className="col-sm-3 col-form-label">Address</label>
//                                         <div className="col-sm-9">
//                                             <input
//                                                 type="text"
//                                                 name="address"
//                                                 className="form-control"
//                                                 placeholder="enter address"
//                                                 value={formData.address}
//                                                 onChange={handleChange}

//                                             />
//                                         </div>
//                                     </div>
//                                     <div className="form-group mb-3 col-md-6">
//                                         <label className="col-sm-3 col-form-label">City</label>
//                                         <div className="col-sm-9">
//                                             <input
//                                                 type="text"
//                                                 name="city"
//                                                 className="form-control"
//                                                 placeholder="enter city"
//                                                 value={formData.city}
//                                                 onChange={handleChange}

//                                             />
//                                         </div>
//                                     </div>

//                                 </div>
//                                 <div className="col-sm-10">
//                                     <button type="submit" className="btn btn-primary">
//                                         Submit
//                                     </button>
//                                 </div>
//                             </form>

//                         </div>
//                     </div>
//                 </div>

//             </div>
//             <ToastContainer />
//         </Fragment>
//     );
// };

// export default EditHospital;
import React, { Fragment, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
// import styles
import 'lightgallery/css/lightgallery.css';
import 'lightgallery/css/lg-zoom.css';
import 'lightgallery/css/lg-thumbnail.css';
import AdminPageTitle from "../../AdminPageTitle/AdminPageTitle";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
const EditHospital = () => {
    const navigate = useNavigate();
    const { id } = useParams();
    const [loading, setLoading] = useState(false);
    const [formData, setFormData] = useState({
        hospital_name: '',
        email: '',
        phone: '',
        local_govt: '',
        address: '',
        type_of_hospital: '',
        state: '',
    });
    const [selectState, setSelectState] = useState('');
    const [state, setState] = useState([]);
	const [city, setCity] = useState([]);
    useEffect(async () => {
        const { data } = await axios.get(`https://naijainsurancebackend.paperbirdtech.com/api/hospital/${id}`)
        console.log("hospital", data);
        const {hospital_name,city,state,type_of_hospital,phone,local_govt,address,email} = data
        setFormData({ 
            hospital_name:hospital_name, 
            email:email, 
            phone:phone, 
            city:city, 
            state:state, 
            type_of_hospital:type_of_hospital, 
            local_govt:local_govt, 
            
            address:address, 
          });
          const responce = await axios.get('https://naijainsurancebackend.paperbirdtech.com/api/hospital/state')
          setState(responce.data)
    }, [])
    const amptyField = (val) => {
        toast.warn(`❗ ${val?val:"Field"} is Empty`, {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
    }
    const handleChange = (e) => {
        const { name, value } = e.target;

        setFormData({
            ...formData,
            [name]: value
        });
        console.log("value", typeof value);
    };
    const getCities =async (value)=>{
        const {data} = await axios.get(`https://naijainsurancebackend.paperbirdtech.com/api/hospital/city/${value}`)
        setCity(data)
        console.log("cities",data);
    }
    const handleStateChange =async (e)=>{
        const {stateValue,value} = e.target
        if(value){
            let selectedState = state.filter((el)=>{ return el.id == value} )
            console.log("selectedState",selectedState[0]);
            setSelectState(selectedState[0].state)
            setFormData({...formData,state:selectedState[0].state})
            getCities(value)
        }
        // handleStateValue()
// console.log("handleStateChange",value);
// console.log("handleStateChange",e.target);

    }
    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true)
        const data = new FormData();
        for (const key in formData) {
            data.append(key, formData[key]);
        }
        if (formData.hospital_name == "") {
            amptyField()
        } else if (formData.email == "") {
            amptyField()
        }
        else if ((!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,6}$/i.test(formData.email))) {
            console.log("dfdsdsdgg");
            toast.warn("❗ Enter valid email", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
        else if (formData.phone == "" || !(formData.phone)) {
            toast.warn("❗ Add Valid Mobile Number", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        } else if (formData.local_govt == "" ) {
            amptyField()
        }
         else if (!formData.city ) {
            amptyField()
        }
        else {
            try {
                const response = await axios.put(`https://naijainsurancebackend.paperbirdtech.com/api/hospital/${id}`, formData);
                console.log('Response data:', response);
                setLoading(false)
                if (response.status == 200) {
                    toast.success("✔️ Submision successful !", {
                        position: "top-right",
                        autoClose: 3000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                }
                navigate("/admin/view/view-hospital");
            } catch (error) {
                console.error('Error submitting HMO data:', error.message);
            }
        }

    };


    return (
        <Fragment>
            <AdminPageTitle activePage="Hospital Management" pageName="Edit Hospital" />

            <div className="col-xl-12 row-lg-12" >
                <div className="card" >
                    <div className="card-header">
                        <h4 className="card-title">Edit Hospital</h4>
                    </div>

                    <div className="card-body">
                        <div className="basic-form">

                            <form onSubmit={handleSubmit}>
                                <div className="row">
                                    <div className="form-group mb-3 col-md-6">
                                        <label className="col-sm-3 col-form-label">Hospital Name</label>
                                        <div className="col-sm-9">
                                            <input
                                                name="hospital_name"
                                                type="text"
                                                className="form-control"
                                                placeholder="enter hospital name"
                                                value={formData.hospital_name}
                                                onChange={handleChange}

                                            />
                                        </div>
                                    </div>

                                    <div className="form-group mb-3 col-md-6">
                                        <label className="col-sm-3 col-form-label">Hospital type</label>
                                        <div className="col-sm-9">
                                            <select
                                                defaultValue={formData.type_of_hospital}
                                                className="form-control form-control-lg"
                                                name="type_of_hospital"
                                                onChange={handleChange}
                                            >
                                                <option >{formData.type_of_hospital?formData.type_of_hospital: "Select Hospital Type"}</option>
                                                <option >Eye Hospital</option>
                                                <option >General Hospital</option>
                                                <option >Specialist Hospital</option>
                                                <option >Dental Hospital</option>
                                                <option >Meternity Hospital</option>
                                            </select>

                                        </div>
                                    </div>
                                </div>

                                <div className="row">
                                    <div className="form-group mb-3 col-md-6">
                                        <label className="col-sm-3 col-form-label">State</label>
                                        <div className="col-sm-9">
                                                        <select
                                                      defaultValue={formData.state}
                                                      className="form-control form-control-lg"
                                                      name="state"
                                                    //   value={formData.state}
                                                      onChange={(e)=>handleStateChange(e)}
                                                    //   onSelect={(e)=>handleStateValue(e)}
                                                      
                                                  >
                                                      {/* <option value={""}>{formData.state?formData.state:"Select State"}</option> */}
{formData.state? <option>{ formData.state}</option> :<option>Select</option> }
                                                      {state && state.map((el)=>{
                                                        return <option value={el.id} key={el.id}  >{el.state}</option>
                                                      })}
                                                  </select>
                                        </div>
                                    </div>
                                    <div className="form-group mb-3 col-md-6">
                                        <label className="col-sm-3 col-form-label">Contact No</label>
                                        <div className="col-sm-9">
                                            <input
                                                name="phone"
                                                type="text"
                                                minLength={10}
                                                maxLength={10}
                                                className="form-control"
                                                placeholder="Contact No"
                                                value={formData.phone}
                                                onChange={handleChange}

                                            />
                                        </div>
                                    </div>


                                </div>
                                <div className="row">


                                    <div className="form-group mb-3 col-md-6">
                                        <label className="col-sm-3 col-form-label">Local Goverment</label>
                                        <div className="col-sm-9">
                                               <select
                                                    //   defaultValue={'Select local govt type'}
                                                      className="form-control form-control-lg"
                                                      name="local_govt"
                                                      value={formData.local_govt}
                                                      onChange={handleChange}
                                                      
                                                  >
                                                    <option value={"Select"}>{formData.local_govt?formData.local_govt:"Select local  govt type"}</option>
                                                    {city? city.map((el,i)=>{
                                                        return(
                                                           <option value={el.city} key={i}>{el.city}</option>
                                                        )
                                                    }): <option value={""}>Select local goverment</option>
                                                }
                                                      {/* <option value={"Select"}>Select local govt type</option> */}
                                                     
                                                  </select>
                                        </div>
                                    </div>
                                    <div className="form-group mb-3 col-md-6">
                                        <label className="col-sm-3 col-form-label">Email</label>
                                        <div className="col-sm-9">
                                            <input
                                                name="email"
                                                type="text"
                                                className="form-control"
                                                placeholder="enter valid email"
                                                value={formData.email}
                                                onChange={handleChange}

                                            />
                                        </div>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="form-group mb-3 col-md-6">
                                        <label className="col-sm-3 col-form-label">Address</label>
                                        <div className="col-sm-9">
                                            <input
                                                type="text"
                                                name="address"
                                                className="form-control"
                                                placeholder="enter address"
                                                value={formData.address}
                                                onChange={handleChange}

                                            />
                                        </div>
                                    </div>
                                    <div className="form-group mb-3 col-md-6">
                                        <label className="col-sm-3 col-form-label">City</label>
                                        <div className="col-sm-9">
                                            <input
                                                type="text"
                                                name="city"
                                                className="form-control"
                                                placeholder="enter city"
                                                value={formData.city}
                                                onChange={handleChange}

                                            />
                                        </div>
                                    </div>

                                </div>
                                <div className="col-sm-10">
                                    <button type="submit" className="btn btn-primary">
                                        Submit
                                    </button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>

            </div>
            <ToastContainer />
        </Fragment>
    );
};

export default EditHospital;

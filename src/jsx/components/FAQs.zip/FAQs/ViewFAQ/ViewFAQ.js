import axios from 'axios';
import React, { useEffect, useState } from 'react'
import {
  Row,
  Col,
  Card,
  Table,
} from "react-bootstrap";
import { Link } from "react-router-dom";
import swal from 'sweetalert';
import { API_URL } from '../../../../config';
 const ViewFAQ = () => {
  let addClass = 'ql-editor frontend';
  const [data, setData] = useState({})
  const [showMoreAns, setShowMoreAns] = useState(false)
  
  useEffect(() => {
    handleGetFAQ()
  }, [])
  const handleGetFAQ = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/faq`);
      console.log('Response data:', response.data);
      setData(response.data)
      return response.data;
    } catch (error) {
      console.error('Error message:', error.message);
      throw error;
    }
  }
  const updatedShowMoreAns = (index) => {
    setShowMoreAns((prev) => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  const handleDelete = async (id) => {
    swal({
      title: "Are you sure?",
      text:
        "Once deleted, you will not be able to recover this record!",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then(async (willDelete) => {
      if (willDelete) {
        try {
          const response = await axios.delete(`${API_URL}/api/faq/delete/${id}`);
          console.log('Response data:', response.data);
          handleGetFAQ()
          return response.data;
        } catch (error) {
          console.error('Error message:', error.message);
          throw error;
        }
      }
    })
    console.log(id, "delete");

  }
  return (
    <div>
      <Card>
        <Card.Header>
          <Card.Title>FAQ Details</Card.Title>
        </Card.Header>
        <Card.Body>
          <Table responsive>
            <thead>
              <tr>
                <th>
                  <strong>Question</strong>
                </th>
                <th>
                  <strong>Answer</strong>
                </th>
                <th>
                  <strong>Action</strong>
                </th>
              </tr>
            </thead>

            <tbody>

              {/* <tr>
                    <td>Question</td>
                    <td>Answer</td>
                    <td>
                      <div className="d-flex">
                        <Link
                          href="#"
                          className="btn btn-primary shadow btn-xs sharp me-1"
                        >
                          <i className="fas fa-pen"></i>
                        </Link>
                        <Link
                          href="#"
                          className="btn btn-danger shadow btn-xs sharp"
                        >
                          <i className="fa fa-trash"></i>
                        </Link>
                      </div>
                    </td>
                
                  </tr> */}
              {data && data.length > 0 && data.map((user, i) => {
                return (
                  <tr key={i}>
                    <td style={{width:'fit-content'}}>
                      {user.faq_question}
                    </td>
                    <td >   
                    <div className={addClass}
                        dangerouslySetInnerHTML={{ __html: showMoreAns[i] ? user.faq_answer : `${(user.faq_answer && user.faq_answer).substring(0, 10)}...` }}></div>
                      <button onClick={() => updatedShowMoreAns(i)} className="btn btn-primary btn-sm">
                        {showMoreAns[i] ? 'Show Less' : 'Show More'}</button>
                    </td>
                    <td >
                      <div className="d-flex">
                        <Link
                          to={`/admin/view/EditFAQs/${user.id}`}
                          className="btn btn-primary shadow btn-xs sharp me-1"
                        >
                          <i className="fas fa-pen"></i>
                        </Link>
                        <Link
                          onClick={() => handleDelete(user.id)}
                          className="btn btn-danger shadow btn-xs sharp"
                        >
                          <i className="fa fa-trash"></i>
                        </Link>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </Table>

          {/* <div  id="example_wrapper" className="dataTables_wrapper">
              <div className="d-sm-flex text-center justify-content-between align-items-center mt-3">
                <div className="dataTables_info">
                  Showing {activePag.current * sort + 1} to{" "}
                  {userData.length > (activePag.current + 1) * sort
                    ? (activePag.current + 1) * sort
                    : userData.length}{" "}
                  of {userData.length} entries
                </div>
                <div
                  className="dataTables_paginate paging_simple_numbers"
                  id="example5_paginate"
                >
                  <Link
                    className="paginate_button previous disabled"
                    to="/admin/view/ViewHMO"
                    onClick={() =>
                      activePag.current > 0 && onClick(activePag.current - 1)
                    }
                  >
                    <i className="fa fa-angle-double-left" aria-hidden="true"></i>
                  </Link>
                  <span>
                    { paggination.map((number, i) => (
                      <Link
                        key={i}
                        to="/admin/view/ViewHMO"
                        className={`paginate_button  ${
                          activePag.current === i ? "current" : ""
                        } `}
                        onClick={() => onClick(i)}
                      >
                        {number}
                      </Link>
                    ))}
                  </span>
                  <Link
                    className="paginate_button next"
                    to="/admin/view/ViewHMO"
                    onClick={() =>
                      activePag.current + 1 < userData.length &&
                      onClick(activePag.current + 1)
                    }
                  >
                    <i className="fa fa-angle-double-right" aria-hidden="true"></i>
                  </Link>
                </div>
              </div>
              </div> */}
        </Card.Body>
      </Card>
    </div>
  )
}
export default ViewFAQ
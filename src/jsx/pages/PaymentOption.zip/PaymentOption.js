import React from "react";
import styles from "../layouts/newstyle.module.css";
import gif from "../../images/naija/970x90_2.gif";
import cx from "classnames";
import "bootstrap/dist/css/bootstrap.min.css";
import { Container, Row, Col, Card } from "react-bootstrap";
import { NavLink } from "react-router-dom"; // Import NavLink from react-router-dom

function PaymentOption() {
  return (
    <div>
      <Container fluid className={styles["main-container"]}>
        <Row className={cx(styles["main-section"], styles["home-section-1"])}>
          <div className="col-md-2 ">
            <div className="card ">
              <div
                className="card-header text-white"
                style={{ backgroundColor: "#69C16B" }}
              >
                Application Summary
              </div>
              <div className="card-body">
                <div className="mb-3">
                  <img
                    src="http://naijamedical.com.ng/images/clear_logo.jpg"
                    alt="Clearline Logo"
                  />
                  <p>Clear line International Family Health Insurance Plan</p>
                </div>
                <div className="mb-3">
                  <strong>Total: ₦28000.00/mo</strong>
                  <p>Estimated Cost (No charge until approved)</p>
                </div>
                <div className="mb-3">
                  <p>Members applying: 1</p>
                  <p>Requested start date: 08/01/2014</p>
                </div>
                <div className="mb-4">
                  <img
                    src="http://naijamedical.com.ng/images/norton_img.jpg"
                    alt="Norton Secured Logo"
                  />
                  <p>ABOUT SSL CERTIFICATES</p>
                </div>
                <div className="mb-3">
                  <h5>Need Help?</h5>
                  <button className="btn btn-link">
                    Click to Talk, We'll call you
                  </button>
                  <p>OR Call on 0123-4567890</p>
                  <p>
                    Mon - Fri, 5AM - 9PM PT
                    <br />
                    Sat - Sun, 7AM - 4PM PT
                  </p>
                </div>
              </div>
            </div>
          </div>

          <Col md={6}>
            <div className="container-sm mt-2">
              <h3 className="pb-2" style={{ color: "#69C16B",fontSize:"40px" }}>
                Buy Plan
              </h3>
              <div className="d-flex flex-column md:gap-1">
                <ul className={`nav nav-tabs ${styles["custom-nav"]}`}>
                  <li className="nav-item flex-fill">
                    <NavLink
                      className={({ isActive }) =>
                        isActive
                          ? `nav-link active ${styles["custom-active"]} text-center bg-primary pt-3 pb-3`
                          : "nav-link text-center pt-3 pb-3 bg-secondary"
                      }
                      to="/buyplan"
                    >
                      Initial Information
                    </NavLink>
                  </li>
                  <li className="nav-item flex-fill">
                    <NavLink
                      className={({ isActive }) =>
                        isActive
                          ? `nav-link active ${styles["custom-active"]} text-center bg-primary pt-3 pb-3`
                          : "nav-link text-center pt-3 pb-3 bg-secondary md:ml-1 md:mr-1"
                      }
                      to="/paymentoption"
                    >
                      Payment Options
                    </NavLink>
                  </li>
                  <li className="nav-item flex-fill ">
                    <NavLink
                      className={({ isActive }) =>
                        isActive
                          ? `nav-link active ${styles["custom-active"]} text-center bg-primary pt-3 pb-3`
                          : "nav-link text-center pt-3 pb-3 bg-secondary"
                      }
                      to="/paymentconfirm"
                    >
                      Payment Confirmation
                    </NavLink>
                  </li>
                </ul>
              </div>

              <div className="container mt-4">
                <h2 className="pb-3 text-primary border-bottom ">
                  Payment Options <i class="ri-bank-card-line"></i>
                </h2>
                <form>
                  <h6 className="mb-3">
                    Pay using Credit Card
                    <img
                      src="https://e7.pngegg.com/pngimages/308/426/png-clipart-visa-logo-credit-card-visa-logo-payment-visa-blue-text-thumbnail.png"
                      alt="Visa"
                      style={{ width: "40px", marginLeft: "10px" }}
                    />
                    <img
                      src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b7/MasterCard_Logo.svg/300px-MasterCard_Logo.svg.png"
                      alt="MasterCard"
                      style={{ width: "40px", marginLeft: "10px" }}
                    />
                    <img
                      src="https://icm.aexp-static.com/Internet/internationalcardshop/en_in/images/cards/en_in-smart-earn-credit-card.png"
                      alt="MasterCard"
                      style={{ width: "40px", marginLeft: "10px" }}
                    />
                  </h6>
                  <div className="form-group d-md-flex gap-5">
                    <div className="form-check">
                      <input
                        className="form-check-input"
                        type="radio"
                        name="paymentMethod"
                        id="netBanking"
                        value="netBanking"
                      />
                      <label className="form-check-label" htmlFor="netBanking">
                        Net Banking
                      </label>
                    </div>
                    <div className="form-check">
                      <input
                        className="form-check-input"
                        type="radio"
                        name="paymentMethod"
                        id="creditCard"
                        value="creditCard"
                      />
                      <label className="form-check-label" htmlFor="creditCard">
                        Credit Card
                      </label>
                    </div>
                    <div className="form-check">
                      <input
                        className="form-check-input"
                        type="radio"
                        name="paymentMethod"
                        id="debitCard"
                        value="debitCard"
                      />
                      <label className="form-check-label" htmlFor="debitCard">
                        Debit Card
                      </label>
                    </div>
                  </div>

                  <div className="form-group mt-3">
                    <label htmlFor="cardNumber">Card Number</label>
                    <input
                      type="text"
                      className="form-control"
                      id="cardNumber"
                      placeholder="Card Number"
                    />
                  </div>
                  <div className="form-row mt-3">
                    <div className="form-group col-md-5">
                      <label htmlFor="expiryDate">Card Expiry Date</label>
                      <input
                        type="text"
                        className="form-control"
                        id="expiryDate"
                        placeholder="MM / YY"
                      />
                    </div>
                    <div className="form-group col-md-4">
                      <label htmlFor="cvv">CVV</label>
                      <input
                        type="text"
                        className="form-control"
                        id="cvv"
                        placeholder="123"
                      />
                    </div>
                    <div className="form-group col-md-1 mt-4">
                      <img
                        src="http://naijamedical.com.ng/images/cvv.jpg"
                        alt="CVV Info"
                        style={{ marginTop: "8px" }}
                      />
                    </div>
                  </div>
                  <div className="form-group mt-3">
                    <label htmlFor="nameOnCard">Name on Card</label>
                    <input
                      type="text"
                      className="form-control"
                      id="nameOnCard"
                      placeholder="Name on Card"
                    />
                  </div>
                  <div className="d-flex justify-content-center mt-4 mb-4">
                    <button type="submit" className="btn btn-lg btn-primary">
                      Pay
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </Col>

          <Col md={2} className="d-none d-md-block">
            <Card className="mb-4">
              <Card.Img
                variant="top"
                src="http://naijamedical.com.ng/images/got_insurance.jpg"
                alt="Placeholder image"
              />
            </Card>
            <Card className="mb-4">
              <Card.Img
                variant="top"
                src="http://naijamedical.com.ng/images/sidebar-1-img.jpg"
                alt="Placeholder image"
              />
            </Card>
            <Card className="mb-4">
              <Card.Img
                variant="top"
                src="http://naijamedical.com.ng/images/l-sidebar-2-img.jpg"
                alt="Placeholder image"
              />
            </Card>
          </Col>
        </Row>

        <Row className={styles["advert"]}>
          <Col>
            <div className="text-center">
              <a
                href="http://www.medicwestafrica.com/"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img src={gif} alt="add1" className="img-fluid" />
              </a>
            </div>
          </Col>
        </Row>

        <Row className="footer-section">
          <Col className="footer margin-top-15"></Col>
        </Row>
      </Container>
    </div>
  );
}

export default PaymentOption;

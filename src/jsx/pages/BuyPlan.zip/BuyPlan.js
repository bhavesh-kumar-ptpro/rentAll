import React, { useState } from 'react';
import { Container, Row, Col, Card } from 'react-bootstrap';
import { NavLink } from 'react-router-dom';
import styles from '../layouts/newstyle.module.css';
import gif from '../../images/naija/970x90_2.gif';
import cx from 'classnames';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Modal, Button } from 'react-bootstrap';


function CustomDatePicker() {
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 100 }, (_, i) => currentYear - i);
  const months = Array.from({ length: 12 }, (_, i) => i + 1);
  const days = Array.from({ length: 31 }, (_, i) => i + 1);

  const [selectedYear, setSelectedYear] = useState(currentYear);
  const [selectedMonth, setSelectedMonth] = useState(1);
  const [selectedDay, setSelectedDay] = useState(1);
  const [date, setDate] = useState('');
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleYearChange = (event) => {
    setSelectedYear(event.target.value);
    updateDate(event.target.value, selectedMonth, selectedDay);
  };

  const handleMonthChange = (event) => {
    setSelectedMonth(event.target.value);
    updateDate(selectedYear, event.target.value, selectedDay);
  };

  const handleDayChange = (event) => {
    setSelectedDay(event.target.value);
    updateDate(selectedYear, selectedMonth, event.target.value);
  };

  const updateDate = (year, month, day) => {
    if (year && month && day) {
      const formattedDate = new Date(year, month - 1, day).toLocaleDateString('en-GB');
      setDate(formattedDate);
    }
  };

  return (
    <div className="form-group">
    
      <div className="input-group">
        <input
          type="text"
          className="form-control"
          placeholder="DD/MM/YYYY"
          value={date}
          readOnly
          onClick={handleShow} // Show the modal on input click
        />
        <div className="input-group-append">
          <span 
            className="input-group-text" 
            style={{ cursor: 'pointer' }} // Change cursor to pointer
            onClick={handleShow} // Show the modal on icon click
          >
            <i className="ri-calendar-2-line"></i>
          </span>
        </div>
      </div>

      <Modal show={show} onHide={handleClose} centered>
        <Modal.Header closeButton  className='bg-primary'>
          <Modal.Title>Select Date of Birth<i class="ri-calendar-2-line text-white"></i></Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="form-group">
            <label>Year</label>
            <select value={selectedYear} onChange={handleYearChange} className="form-control">
              {years.map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Month</label>
            <select value={selectedMonth} onChange={handleMonthChange} className="form-control">
              {months.map(month => (
                <option key={month} value={month}>{month}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Day</label>
            <select value={selectedDay} onChange={handleDayChange} className="form-control">
              {days.map(day => (
                <option key={day} value={day}>{day}</option>
              ))}
            </select>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Date
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}



function BuyPlan() {
  return (
    <div>
      <Container fluid className={styles['main-container']}>
        <Row className={cx(styles['main-section'], styles['home-section-1'])}>
          <div className="col-md-2 ">
            <div className="card ">
              <div
                className="card-header text-white"
                style={{ backgroundColor: '#69C16B' }}
              >
                Application Summary
              </div>
              <div className="card-body">
                <div className="mb-3">
                  <img
                    src="http://naijamedical.com.ng/images/clear_logo.jpg"
                    alt="Clearline Logo"
                  />
                  <p>Clear line International Family Health Insurance Plan</p>
                </div>
                <div className="mb-3">
                  <strong>Total: ₦28000.00/mo</strong>
                  <p>Estimated Cost (No charge until approved)</p>
                </div>
                <div className="mb-3">
                  <p>Members applying: 1</p>
                  <p>Requested start date: 08/01/2014</p>
                </div>
                <div className="mb-4">
                  <img
                    src="http://naijamedical.com.ng/images/norton_img.jpg"
                    alt="Norton Secured Logo"
                  />
                  <p>ABOUT SSL CERTIFICATES</p>
                </div>
                <div className="mb-3">
                  <h5>Need Help?</h5>
                  <button className="btn btn-link">
                    Click to Talk, We'll call you
                  </button>
                  <p>OR Call on 0123-4567890</p>
                  <p>
                    Mon - Fri, 5AM - 9PM PT
                    <br />
                    Sat - Sun, 7AM - 4PM PT
                  </p>
                </div>
              </div>
            </div>
          </div>

          <Col md={6}>
            <div className="container-sm mt-2">
              <h3 className="pb-2" style={{ color: '#69C16B', fontSize: '40px' }}>
                Buy Plan
              </h3>
              <div className="d-flex flex-column md:gap-1">
                <ul className={`nav nav-tabs ${styles['custom-nav']}`}>
                  <li className="nav-item flex-fill">
                    <NavLink
                      className={({ isActive }) =>
                        isActive
                          ? `nav-link active ${styles['custom-active']} text-center bg-primary pt-3 pb-3`
                          : 'nav-link text-center pt-3 pb-3 bg-secondary'
                      }
                      to="/buyplan"
                    >
                      Initial Information
                    </NavLink>
                  </li>
                  <li className="nav-item flex-fill">
                    <NavLink
                      className={({ isActive }) =>
                        isActive
                          ? `nav-link active ${styles['custom-active']} text-center bg-primary pt-3 pb-3`
                          : 'nav-link text-center pt-3 pb-3 bg-secondary md:ml-1 md:mr-1'
                      }
                      to="/paymentoption"
                    >
                      Payment Options
                    </NavLink>
                  </li>
                  <li className="nav-item flex-fill">
                    <NavLink
                      className={({ isActive }) =>
                        isActive
                          ? `nav-link active ${styles['custom-active']} text-center bg-primary pt-3 pb-3`
                          : 'nav-link text-center pt-3 pb-3 bg-secondary'
                      }
                      to="/paymentconfirm"
                    >
                      Payment Confirmation
                    </NavLink>
                  </li>
                </ul>
              </div>

              <form className="mt-4">
                <div className="form-group">
                  <h4 className={styles['section-header']}>
                    Primary Applicant Information <i className="ri-information-line"></i>
                  </h4>
                  <div className="row">
                    <div className="col-md-5">
                      
                      <input
                        type="text"
                        className="form-control"
                        placeholder="First Name"
                      />
                    </div>
                    <div className="col-md-3">
                      
                      <input
                        type="text"
                        className="form-control"
                        placeholder="MI"
                      />
                    </div>
                    <div className="col-md-3">
                      
                      <select className="form-control">
                        <option>Male</option>
                        <option>Female</option>
                      </select>
                    </div>
                  </div>
                  <div className="row mt-3">
                    <div className="col-md-5">
                      
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Last Name"
                      />
                    </div>
                    <div className="col-md-5">
                      <CustomDatePicker />
                    </div>
                  </div>
                </div>

                <div className="form-group mt-4">
                  <h4 className={styles['section-header']}>
                    Address Information <i className="ri-information-line"></i>
                  </h4>
                  <p>
                    Home Address (P.O. Box is not acceptable - please provide
                    place of residence)
                  </p>
                  <div className="row">
                    <div className="col-md-6">
                      
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Street"
                      />
                    </div>
                    <div className="col-md-5">
                      
                      <input
                        type="text"
                        className="form-control"
                        placeholder="City"
                      />
                    </div>
                  </div>
                  <div className="row mt-3">
                    <div className="col-md-4">
                      
                      <input
                        type="text"
                        className="form-control"
                        placeholder="State"
                      />
                    </div>
                    <div className="col-md-4">
                      
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Country"
                      />
                    </div>
                    <div className="col-md-3">
                      
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Zip"
                      />
                    </div>
                  </div>
                </div>

                <div className="form-group mt-4">
                  <label>
                    * Is the Mailing Address different from your Home Address?
                  </label>
                  <div>
                    <button type="button" className="btn btn-primary mr-2">
                      Yes
                    </button>
                    <button type="button" className="btn btn-secondary">
                      No
                    </button>
                  </div>
                </div>

                {/* New Contact Information Fields */}
                <div className="form-group mt-4">
                  <h4 className={styles['section-header']}>
                    Contact Information <i className="ri-contacts-line"></i>
                  </h4>
                  <div className="row">
                    <div className="col-md-3">
                      
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Enter daytime"
                        required
                      />
                    </div>
                    <div className="col-md-4">
                      
                      <input
                        type="tel"
                        className="form-control"
                        placeholder="Enter phone"
                      />
                    </div>
                    <div className="col-md-4">
                      
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Enter street"
                        required
                      />
                    </div>
                  </div>
                </div>
                {/* End of New Contact Information Fields */}
                <div className="d-flex justify-content-between mt-4 mb-4">
                  <button type="button" className="btn btn-lg btn-secondary">
                    Back
                  </button>
                  <NavLink to="/paymentoption">
                    <button type="submit" className="btn btn-lg btn-primary">
                      Continue
                    </button>
                  </NavLink>
                </div>
              </form>
            </div>
          </Col>

          <Col md={2} className="d-none d-md-block">
            <Card className="mb-4">
              <Card.Img
                variant="top"
                src="http://naijamedical.com.ng/images/got_insurance.jpg"
                alt="Placeholder image"
              />
            </Card>
            <Card className="mb-4">
              <Card.Img
                variant="top"
                src="http://naijamedical.com.ng/images/sidebar-1-img.jpg"
                alt="Placeholder image"
              />
            </Card>
            <Card className="mb-4">
              <Card.Img
                variant="top"
                src="http://naijamedical.com.ng/images/l-sidebar-2-img.jpg"
                alt="Placeholder image"
              />
            </Card>
          </Col>
        </Row>

        <Row className={styles['advert']}>
          <Col>
            <div className="text-center">
              <a
                href="http://www.medicwestafrica.com/"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img src={gif} alt="add1" className="img-fluid" />
              </a>
            </div>
          </Col>
        </Row>

        <Row className="footer-section">
          <Col className="footer margin-top-15"></Col>
        </Row>
      </Container>
    </div>
  );
}

export default BuyPlan;

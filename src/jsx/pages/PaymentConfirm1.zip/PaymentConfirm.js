import React from "react";
import styles from "../layouts/newstyle.module.css";
import gif from "../../images/naija/970x90_2.gif";
import cx from "classnames";
import "bootstrap/dist/css/bootstrap.min.css";
import { Container, Row, Col, Card } from "react-bootstrap";
import sidebar1 from "../../images/naija/sidebar-1-img.jpg";
import sidebar2 from "../../images/naija/sidebar-2-img.jpg";
import help_call from "../../images/naija/help_call.jpg";
import got_insurance from "../../images/naija/got_insurance.jpg";
import married from "../../images/naija/married.svg";
import unmarried from "../../images/naija/unmarried.svg";
import { NavLink } from "react-router-dom"; // Import NavLink from react-router-dom
import { useNavigate, useParams,useLocation } from 'react-router-dom';

function PaymentConfirm() {
  const { id } = useParams();
  return (
    <div>
      <Container fluid className={styles["main-container"]}>
        <Row className={cx(styles["main-section"], styles["home-section-1"])}>
          <div className="col-md-2 ">
            <div className="card">
              <div
                className="card-header text-white"
                style={{ backgroundColor: "#69C16B" }}
              >
                Application Summary
              </div>
              <div className="card-body">
                <div className="mb-3">
                  <img
                    src="http://naijamedical.com.ng/images/clear_logo.jpg"
                    alt="Clearline Logo"
                  />
                  <p>Clear line International Family Health Insurance Plan</p>
                </div>
                <div className="mb-3">
                  <strong>Total: ₦28000.00/mo</strong>
                  <p>Estimated Cost (No charge until approved)</p>
                </div>
                <div className="mb-3">
                  <p>Members applying: 1</p>
                  <p>Requested start date: 08/01/2014</p>
                </div>
                <div className="mb-4">
                  <img
                    src="http://naijamedical.com.ng/images/norton_img.jpg"
                    alt="Norton Secured Logo"
                  />
                  <p>ABOUT SSL CERTIFICATES</p>
                </div>
                <div className="mb-3">
                  <h5>Need Help?</h5>
                  <button className="btn btn-link">
                    Click to Talk, We'll call you
                  </button>
                  <p>OR Call on 0123-4567890</p>
                  <p>
                    Mon - Fri, 5AM - 9PM PT
                    <br />
                    Sat - Sun, 7AM - 4PM PT
                  </p>
                </div>
              </div>
            </div>
          </div>

          <Col md={6}>
            <div className="container-sm mt-2">
              <h3 className="pb-2" style={{ color: "#69C16B" }}>
                Buy Plan
              </h3>
              <ul className="nav nav-tabs w-100 custom-nav md:flex md:flex-row">
                <li className="nav-item w-full">
                  <NavLink
                    className={({ isActive }) =>
                      isActive
                        ? "nav-link active custom-active text-center"
                        : "nav-link text-center"
                    }
                    to={`/user/buyplan/${id}`}
                  >
                    Initial Information
                  </NavLink>
                </li>
                <li className="nav-item w-full">
                  <NavLink
                    className={({ isActive }) =>
                      isActive
                        ? "nav-link active custom-active text-center"
                        : "nav-link text-center"
                    }
                    to={`/user/paymentoption/${id}`}
                  >
                    Payment Options
                  </NavLink>
                </li>
                <li className="nav-item w-full">
                  <NavLink
                    className={({ isActive }) =>
                      isActive
                        ? "nav-link active custom-active text-center"
                        : "nav-link text-center"
                    }
                    to={`/user/paymentconfirm/${id}`}
                  >
                    Payment Confirmation
                  </NavLink>
                </li>
              </ul>

              <div className="container mt-4">
                <h2
                  className="pb-2 text-primary"
                  style={{ borderBottom: "1px solid #D3D3D3" }} // Add a border-bottom style
                >
                  Payment Confirmation
                </h2>
                <div className="text-center mt-4">
                  <p style={{ fontSize: "1.25rem" }}>
                    Your Payment is Successfully Processed.
                  </p>
                  <p style={{ fontSize: "1.25rem" }}>
                    Your Order Reference ID is: PS5438659
                  </p>
                  <p style={{ fontSize: "1.25rem" }}>
                    Please Click below to view your Enrollment Details
                  </p>
                  <div className="mt-4 mb-4">
                    <button className="btn btn-lg  btn-primary">
                      Click Here!
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </Col>

          <Col md={2} className="d-none d-md-block">
            <div className={styles["sidebar"]}> <img alt="sidebar-1-img" src={help_call} /> </div>
                <div className={styles["sidebar"]}> <img alt="sidebar-1-img" src={sidebar1} /> </div>
                <div className={styles["sidebar"]}> <img alt="sidebar-2-img" src={got_insurance} /> </div>
          </Col>
        </Row>

        <Row className={styles["advert"]}>
          <Col>
            <div className="text-center">
              <a
                href="http://www.medicwestafrica.com/"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img src={gif} alt="add1" className="img-fluid" />
              </a>
            </div>
          </Col>
        </Row>

        <Row className="footer-section">
          <Col className="footer margin-top-15"></Col>
        </Row>
      </Container>
    </div>
  );
}

export default PaymentConfirm;

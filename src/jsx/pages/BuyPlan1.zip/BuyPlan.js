import React from "react";
import { Container, Row, Col, Card } from "react-bootstrap";
import { NavLink } from "react-router-dom"; // Import NavLink from react-router-dom
import styles from "../layouts/newstyle.module.css";
import gif from "../../images/naija/970x90_2.gif";
import cx from "classnames";
import "bootstrap/dist/css/bootstrap.min.css";
import sidebar1 from "../../images/naija/sidebar-1-img.jpg";
import sidebar2 from "../../images/naija/sidebar-2-img.jpg";
import help_call from "../../images/naija/help_call.jpg";
import got_insurance from "../../images/naija/got_insurance.jpg";
import married from "../../images/naija/married.svg";
import unmarried from "../../images/naija/unmarried.svg";
import { useNavigate, useParams,useLocation } from 'react-router-dom';

function BuyPlan() {
  const { id } = useParams();
  const handleSubmit = async (e) => {
    // console.log("formData", formData);
    // setLoading(true)
    // e.preventDefault();
    // const data = new FormData();
    // // for (const key in formData) {
    // //     data.append(key, formData[key]);
    // // }
    // if (formData.first_name == "") {
    //   amptyField("first name");

    // } else if (formData.last_name == "") {
    //   amptyField("last name")
    // } else if (formData.email == "" || !formData.email) {
    //   amptyField("Email")

    // }
    // else if (
    //   formData.dob == "" ||
    //   !formData.dob
    // ) {
    //   amptyField("Date of Birth")
    // }
    // // else if (formData.state == "" || !formData.state) {
    // //   amptyField("state")

    // // } else if (formData.local_govt == "" || !formData.local_govt) {
    // //   amptyField("local govt")
    // // }
    // else if (formData.budget == "" || !formData.budget) {
    //   amptyField("budget")

    // } else if (formData.conditions == "" || !formData.conditions) {
    //   amptyField("conditions")

    // }
    // // else if (formData.age == "" || !formData.age) {
    // //   amptyField("Age")

    // // }
    // else {
    //   try {
    //     const { data } = await axios.post(`${API_URL}/api/indivual_plan_master`, formData);
    //     setLoading(false)
    //     console.log("data", data);
    //     if (data.status == 400) {

    //       toast.error(`${data.message}`)
    //     } else {
    //       toast.success("✔️ Submision successful !", {
    //         position: "top-right",
    //         autoClose: 2500,
    //         hideProgressBar: false,
    //         closeOnClick: true,
    //         pauseOnHover: true,
    //         draggable: true,
    //         progress: undefined,
    //       });
    //     }
    //     localStorage.setItem('lastLocation',`/user/search_result?&localGovt=${formData.local_govt}&state=${formData.state}&budget=${formData.budget}&planType=Individual & Family`);
    //     // window.myGlobalVariable = `/user/search_result?&localGovt=${formData.local_govt}&state=${formData.state}&budget=${formData.budget}&planType=Individual & Family`;
    //     // setGlobalVariable(`/user/search_result?&localGovt=${formData.local_govt}&state=${formData.state}&budget=${formData.budget}&planType=Individual & Family`);
    //     setInterval(() => {
    //      window.location=`/user/search_result?&localGovt=${formData.local_govt}&state=${formData.state}&budget=${formData.budget}&planType=Individual & Family`;
    //       reset();
    //     }, 1500)
    //   } catch (error) {
    //     console.error('Error submitting HMO data:', error.message);
    //     toast.error(`${error.message}`)
    //   }
    // }
  };
  return (
    <div>
      <Container fluid className={styles["main-container"]}>
        <Row className={cx(styles["main-section"], styles["home-section-1"])}>
          <div className="col-md-2 ">
            <div className="card ">
              <div
                className="card-header  text-white"
                style={{ backgroundColor: "#69C16B" }}
              >
                Application Summary
              </div>
              <div className="card-body">
                <div className="mb-3">
                  <img
                    src="http://naijamedical.com.ng/images/clear_logo.jpg"
                    alt="Clearline Logo"
                  />
                  <p>Clear line International Family Health Insurance Plan</p>
                </div>
                <div className="mb-3">
                  <strong>Total: ₦28000.00/mo</strong>
                  <p>Estimated Cost (No charge until approved)</p>
                </div>
                <div className="mb-3">
                  <p>Members applying: 1</p>
                  <p>Requested start date: 08/01/2014</p>
                </div>
                <div className="mb-4">
                  <img
                    src="http://naijamedical.com.ng/images/norton_img.jpg"
                    alt="Norton Secured Logo"
                  />
                  <p>ABOUT SSL CERTIFICATES</p>
                </div>
                <div className="mb-3">
                  <h5>Need Help?</h5>
                  <button className="btn btn-link">
                    Click to Talk, We'll call you
                  </button>
                  <p>OR Call on 0123-4567890</p>
                  <p>
                    Mon - Fri, 5AM - 9PM PT
                    <br />
                    Sat - Sun, 7AM - 4PM PT
                  </p>
                </div>
              </div>
            </div>
          </div>

          <Col md={6}>
            <div className="container-sm mt-2">
              <h3 className="pb-2" style={{ color: "#69C16B" }}>
                Buy Plan
              </h3>

              <ul className="nav nav-tabs w-100 custom-nav md:flex md:flex-row">
                <li className="nav-item w-full">
                  <NavLink
                    className={({ isActive }) =>
                      isActive
                        ? "nav-link active custom-active text-center"
                        : "nav-link text-center"
                    }
                    to={`/user/buyplan/${id}`}
                  >
                    Initial Information
                  </NavLink>
                </li>
                <li className="nav-item w-full">
                  <NavLink
                    className={({ isActive }) =>
                      isActive
                        ? "nav-link active custom-active text-center"
                        : "nav-link text-center"
                    }
                    to={`/user/paymentoption/${id}`}
                  >
                    Payment Options
                  </NavLink>
                </li>
                <li className="nav-item w-full">
                  <NavLink
                    className={({ isActive }) =>
                      isActive
                        ? "nav-link active custom-active text-center"
                        : "nav-link text-center"
                    }
                    to={`/user/paymentconfirm/${id}`}
                  >
                    Payment Confirmation
                  </NavLink>
                </li>
              </ul>

              <form className="mt-4" onSubmit={handleSubmit}>
                <div className="form-group">
                  <h4 className={styles["section-header"]}>
                    Primary Applicant Information
                  </h4>
                  <div className="row">
                    <div className="col-md-5">
                      <label>*First Name</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="First Name"
                        name="first_name"
                      />
                    </div>
                    <div className="col-md-3">
                      <label>MI</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="MI"
                         name="marriage_status"
                      />
                    </div>
                    <div className="col-md-3">
                      <label>Sex</label>
                      <select className="form-control" name="gender">
                        <option>Male</option>
                        <option>Female</option>
                      </select>
                    </div>
                  </div>
                  <div className="row mt-3">
                    <div className="col-md-5">
                      <label>*Last Name</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Last Name"
                      />
                    </div>
                    <div className="col-md-5">
                      <label>Date of Birth</label>
                      <input type="date" className="form-control" />
                    </div>
                  </div>
                </div>

                <div className="form-group mt-4">
                  <h4 className={styles["section-header"]}>
                    Address Information
                  </h4>
                  <p>
                    Home Address (P.O. Box is not acceptable - please provide
                    place of residence)
                  </p>
                  <div className="row">
                    <div className="col-md-6">
                      <label>*Street</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Street"
                      />
                    </div>
                    <div className="col-md-5">
                      <label>*City (Please do not abbreviate)</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="City"
                      />
                    </div>
                  </div>
                  <div className="row mt-3">
                    <div className="col-md-4">
                      <label>State</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="State"
                      />
                    </div>
                    <div className="col-md-4">
                      <label>Country</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Country"
                      />
                    </div>
                    <div className="col-md-3">
                      <label>Zip</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Zip"
                      />
                    </div>
                  </div>
                </div>

                <div className="form-group mt-4">
                  <label>
                    * Is the Mailing Address different from your Home Address?
                  </label>
                  <div>
                    <button type="button" className="btn btn-primary mr-2">
                      Yes
                    </button>
                    <button type="button" className="btn btn-secondary">
                      No
                    </button>
                  </div>
                </div>
                <div className="form-group mt-4">
                  <h4 className={styles["section-header"]}>
                    Contact Information
                  </h4>
                  <div className="row">
                    <div className="col-md-3">
                      <label>*Day time</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Enter daytime"
                        required
                      />
                    </div>
                    <div className="col-md-4">
                      <label>Phone</label>
                      <input
                        type="tel"
                        className="form-control"
                        placeholder="Enter phone"
                      />
                    </div>
                    <div className="col-md-4">
                      <label>*Street</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Enter street"
                        required
                      />
                    </div>
                  </div>
                </div>
                <div className="d-flex justify-content-between mt-4 mb-4">
                  <button type="button" className="btn btn-lg btn-secondary">
                    Back
                  </button>
                  <NavLink to={`/user/paymentoption/${id}`}>
                    <button type="submit" className="btn btn-lg btn-primary">
                      Continue
                    </button>
                  </NavLink>
                </div>
              </form>
            </div>
          </Col>

          <Col md={2} className="d-none d-md-block">
            <div className={styles["sidebar"]}> <img alt="sidebar-1-img" src={help_call} /> </div>
                <div className={styles["sidebar"]}> <img alt="sidebar-1-img" src={sidebar1} /> </div>
                <div className={styles["sidebar"]}> <img alt="sidebar-2-img" src={got_insurance} /> </div>
          </Col>
        </Row>

        <Row className={styles["advert"]}>
          <Col>
            <div className="text-center">
              <a
                href="http://www.medicwestafrica.com/"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img src={gif} alt="add1" className="img-fluid" />
              </a>
            </div>
          </Col>
        </Row>

        <Row className="footer-section">
          <Col className="footer margin-top-15"></Col>
        </Row>
      </Container>
    </div>
  );
}

export default BuyPlan;
